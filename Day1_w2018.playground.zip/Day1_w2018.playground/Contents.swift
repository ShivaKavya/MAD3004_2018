//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var s:Int=1000

s=100

var a,b,c:Int

a=1000
b=2000
c=300

let x = 5000

let y:Int
y=5000

var z=y

z=10

print(str)
print(s)
print(x)
print(y,z)

/*c = a + b
print(c)
 print(c, "=", a, "+", b)
print("\(a) + \(b) = \(c)")
print(c, "=", a, "+", b, separator: " ###", terminator:" -- ")
*/

if(a>b && a>c)
{
        print("a is greater")
}
else if(b>a && b>c)
{
    print("b is greater")
}
else
{
    print("c is greater")
}

for i in 1..<10 {
 print(i)
}

for i in stride(from: 0, to: 50, by:5 ){
 print(i)
}

var k:Int = 1
while(k<=10) {
    print(k)
   k=k+1
}

var j=1
repeat
{
    print(j)
    j = j + 1
    
}while(j <= 10)

var l = (10,20)
print(l.0)
print(l.1)

var ll = (a, b)




















